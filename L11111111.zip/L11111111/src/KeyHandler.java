import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyHandler implements KeyListener {
    boolean upPressed, downPressed, upPressed1, downPressed1;


    public void keyTyped(KeyEvent e) {

    }


    public void keyPressed(KeyEvent e) {

        int klawisz = e.getKeyCode();
        if (klawisz == KeyEvent.VK_W){
            upPressed = true;
        }
        if (klawisz == KeyEvent.VK_S){
            downPressed = true;
        }

        if (klawisz == KeyEvent.VK_UP){
            upPressed1 = true;
        }
        if (klawisz == KeyEvent.VK_DOWN){
            downPressed1 = true;
        }




    }


    public void keyReleased(KeyEvent e) {
        int klawisz = e.getKeyCode();
        if (klawisz == KeyEvent.VK_W){
            upPressed = false;
        }
        if (klawisz == KeyEvent.VK_S){
            downPressed = false;
        }


        if (klawisz == KeyEvent.VK_UP){
            upPressed1 = false;
        }
        if (klawisz == KeyEvent.VK_DOWN){
            downPressed1 = false;
        }
    }
}
