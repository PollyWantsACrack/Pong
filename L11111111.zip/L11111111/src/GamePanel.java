import javax.swing.JPanel;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.Console;
import java.util.Random;

public class GamePanel extends JPanel implements Runnable {

    public final int screenWidth = 768;
    public final int screenHeight = 576;
    KeyHandler kh = new KeyHandler();


    int FPS = 60;

    int czas = 9;

    Thread gameThread;

    Random random = new Random();
    public int playerX = 50;
    public int playerY = 100+88;

    public int ballX = 768/2-25;
    public int  ballY = 576/2-25;

    public int collisionCase;

    public int ballSpeedX = 6;
    public int ballSpeedY = random.nextInt(6)-3;

    public int playerX1 = 768-50-50;
    public int playerY1 = 188;
    int playerSpeed = 8;

    public int pointsA;
    public int pointsB;

    int countShots;




    public GamePanel() {
        this.setBackground(Color.black);
        this.setPreferredSize(new Dimension(screenWidth, screenHeight));
        this.addKeyListener(kh);
        this.setFocusable(true);
    }

    public void startGameThread() {
        gameThread = new Thread(this);
        gameThread.start();
    }

    public void run() {

        long FPS = 60;
        double drawInterval = 1000/FPS;
        double deltaTime = 0;
        long lastTime = System.currentTimeMillis();



        while (gameThread != null) {



            long currentTime = System.currentTimeMillis();

        deltaTime = deltaTime + (currentTime - lastTime) / drawInterval;

        lastTime = currentTime;

        if(deltaTime >= 1) {
            update();
            repaint();
            deltaTime--;
            if(pointsA == 5 || pointsB == 5){
                if(pointsA == 5){
                    javax.swing.JOptionPane.showMessageDialog(null, "Koniec gry zwycięża gracz lewy, wynik  :      " + pointsA + ":" + pointsB);
                } else if (pointsB == 5 ){
                    javax.swing.JOptionPane.showMessageDialog(null, "Koniec gry zwycięża gracz prawy, wynik :      " + pointsA + ":" + pointsB);
                }

                System.exit(0); // Zamyka aplikację
            }

        }
        }
    }

    public void update() {
        if (kh.upPressed == true) {
            playerY = playerY - playerSpeed;
        }
        if (kh.downPressed == true) {
            playerY = playerY + playerSpeed;
        }
        if (playerY < 0) {
            playerY = 0;
        }
        if (playerY > 376) {
            playerY = 376;
        }



        if (kh.upPressed1 == true) {
            playerY1 = playerY1 - playerSpeed;
        }
        if (kh.downPressed1 == true) {
            playerY1 = playerY1 + playerSpeed;
        }
        if (playerY1 < 0) {
            playerY1 = 0;
        }
        if (playerY1 > 376) {
            playerY1 = 376;
        }
        ballX = ballX + ballSpeedX;
        ballY = ballY + ballSpeedY;

        if (ballX > playerX1 - 25 && ballY > playerY1 && ballY < playerY1+200){
            ballX = playerX1 - 25;
            collisionCase = 2;
        }

        if (ballX < playerX + 50 && ballY > playerY && ballY < playerY+200){
            ballX = playerX + 50;
            collisionCase = 1;
        }
        if(ballY < 0){
            ballY = 0;
            collisionCase = 3;
        }
        if(ballY > 576-25){
            ballY = 576-25;
            collisionCase = 4;
        }
        if(ballX>768){
            ballX = 768/2-25;
            ballY = 576/2-25;
            pointsA++;
        }
        if(ballX<0){
            ballX = 768/2-25;
            ballY = 576/2-25;
            pointsB++;

        }

        switch (collisionCase){
            case 1:
                //System.out.println("kolizja z paletką lewą");
                ballSpeedX = 6 + countShots/60;

                if(ballSpeedY > 0){
                    ballSpeedY = 2 + countShots/120;
                }else {
                    ballSpeedY = -2 - countShots/120;
                }
                countShots++;
                //(int)Math.floor(Math.random()* (min - max + 1)+ min);
                break;
            case 2:
                //System.out.println("kolizja z paletką prawą");
                ballSpeedX = -6 - countShots/60;

                if(ballSpeedY > 0){
                    ballSpeedY = 2 + countShots/120;
                }else {
                    ballSpeedY = -2 - countShots/120;
                }


                break;
            case 3:
                //System.out.println("kolizja z górną krawędzią ekranu");
                ballSpeedY = 2 + countShots/120;
                break;
            case 4:
                //System.out.println("kolizja z dolną krawędzią ekranu");
                ballSpeedY = -2 -countShots/120;
                break;
        }



    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        paletka1(g2);
        paletka2(g2);
        kulka(g2);


    }

    public void paletka1(Graphics2D g2) {
        g2.setColor(Color.WHITE);
        g2.fillRect(playerX, playerY, 50, 200);
    }

    public void paletka2(Graphics2D g2) {
        g2.setColor(Color.WHITE);
        g2.fillRect(playerX1, playerY1, 50, 200);
    }
    public void kulka(Graphics2D g2) {
        g2.setColor(Color.WHITE);
        g2.fillOval(ballX, ballY, 25, 25);

    }
}
